const http = require("http");
const fs = require("fs");
let tax = 0;

// Calculate Tax Function
const calTax = (s) => {
  if (s >= 100000 && s < 200000) {
    tax = s * 0.1;
  } else if (s >= 200000 && s < 300000) {
    tax = s * 0.15;
  } else if (s >= 300000 && s < 400000) {
    tax = s * 0.2;
  } else if (s >= 400000 && s < 500000) {
    tax = s * 0.25;
  }
  return tax;
};

// Creating Server Instance
const server = http.createServer((req, res) => {
  const url = req.url;
  if (url === "/") {
    res.setHeader("Content-Type", "text/html");
    res.write("<html>");
    res.write("<head>");
    res.write("<title>");
    res.write("Learn Nodejs - Lec 1");
    res.write("</title>");
    res.write("</head>");
    res.write("<body>");
    res.write('<form action="message" method="POST">');
    res.write('<input type="text" name="message" />');
    res.write("<button>Send</button>");
    res.write("</form>");
    res.write("</body>");
    res.write("</html>");
    res.end();
  }

  if (url === "/message" && req.method === "POST") {
    const body = [];

    req.on("data", (chunk) => {
      console.log("chunk", chunk);
      body.push(chunk);
    });
    req.on("end", () => {
      const message = Buffer.concat(body).toString();
      const salary = message.split("=")[1];
      console.log("Salary is ", salary);
      console.log("Tax is ", calTax(salary));
      fs.writeFileSync("messages.txt", message);
      res.statusCode = 302;
      res.setHeader("Location", "/");
      res.end();
    });
  }
});

server.listen(5500);
